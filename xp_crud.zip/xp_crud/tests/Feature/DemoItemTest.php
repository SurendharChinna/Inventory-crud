<?php

namespace Tests\Feature;

use App\Models\Category;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Illuminate\Foundation\Testing\WithFaker;
use Tests\TestCase;
use App\Models\Item;
use Illuminate\Validation\Rules\Unique;

class DemoItemTest extends TestCase
{
    // use RefreshDatabase;
    /**
     * A basic feature test example.
     *
     * @return void
     */
        private $CATEGORY_HEADERS = [
        'Authorization' => 'Bearer xp_crud_invent',
        'Accept' => 'application/json'
    ];

    // private $CATEGORY_HEADERS='xp_crud_invent';
    public function test_unauthorizedCategoryDetails()
    {

        $response = $this->postJson('/api/category',[
            'name'=>'Testing.',
            'description'=>'testing descp']);

        $response->assertStatus(403);
    }
    public function test_store_Category()
    {
        $response=$this->withHeaders(
$this->CATEGORY_HEADERS,)->postJson('/api/category',[
            'name' => 'almon'.time(),
            'description' => 'Green',
            ]);

        $response->assertStatus(201);

    }
    public function testUpdatePost()
    {
        $category = Category::orderBy('id','DESC')->first();

        $response = $this->withHeaders($this->CATEGORY_HEADERS,
        )->putJson('/api/category' .$category->id,[
            'name' => 'almonr'. uniqid(),
            'description' => 'Green',
        ]);

        $response->assertStatus(201);


    }
    public function testUpdatePostNotFound(){
        $response = $this->withHeaders($this->CATEGORY_HEADERS,
        )->putJson('/api/category/555',[
            'name' => 'almon'.uniqid(),
            'description' => 'Green',
        ]);
        $response->assertStatus(404);
    }


    public function testGetCategoryDetailsId()
    {



        $response = $this->withHeaders($this->CATEGORY_HEADERS,
    )->getJson('api/category');

        $response->assertStatus(200);

    }
    public function testGetCategoryDetailslist()
    {



        $response = $this->withHeaders($this->CATEGORY_HEADERS,
    )->getJson('api/category/1');

        $response->assertStatus(200);

    }
    public function testGetCategoryDetailsdeleteIdNotFound()
    {
        $response = $this->withHeaders($this->CATEGORY_HEADERS,
        )->getJson('api/category/10000');
        $response->assertStatus(404);

    }
    public function testdeleteIdNotFound()
    {



        $response = $this->withHeaders($this->CATEGORY_HEADERS,
        )->delete('api/category/555');
        $response->assertStatus(404);

    }
    public function testDeleteCategory()
    {
        $category = Category::OrderBy('id', 'DESC')->first();;
        $response = $this->withHeaders($this->CATEGORY_HEADERS,
        )->delete('api/category/'. $category->id);
        $response->assertStatus(200);
    }
}
