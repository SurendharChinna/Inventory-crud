<x-mail::message>
#Item updated
<p> Item Details: </p>
<div>
    Name:{{$item->name}}<br>
    Description:{{$item->description}}<br>
    Price:{{$item->price}}<br>
    Quantity:{{$item->quantity}}<br>
    Created at: {{$item->created_at}}<br>
    Updated at: {{$item->updated_at}}<br>
</div>

<br>
Thanks, <br>
{{ config('app.name')}}
</x-mail::message>
