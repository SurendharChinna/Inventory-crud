<x-mail::message>
#Item Deleted
<p> Item Details: </p>
<div>
    <p> Item is Deleted with mapping table </p>
</div>

<br>
Thanks, <br>
{{ config('app.name')}}
</x-mail::message>
