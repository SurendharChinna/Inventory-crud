<?php

namespace App\Http\Middleware;

use Closure;
use Illuminate\Http\Request;
use Symfony\Component\HttpFoundation\Response;

class ApiAuthValidation
{
    /**
     * Handle an incoming request.
     *
     * @param  \Closure(\Illuminate\Http\Request): (\Symfony\Component\HttpFoundation\Response)  $next
     */
    public function handle(Request $request, Closure $next): Response
    {
        $token=$request->bearerToken();
        // return response([ 'rew'=> env('INVENTORY_API_TOKEN')]);
        if($token==env('INVENTORY_API_TOKEN')){
            return $next($request);
        }
        else
        {
            return response([
                'message'=>'Not Authenticated'
            ],404);
        }

    }
}
