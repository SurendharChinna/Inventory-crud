<?php

namespace App\Http\Controllers;

use App\Http\Requests\CreateCategoryRequest;
use App\Http\Requests\UpdateCategoryRequest;
use App\Http\Resources\CategoryResource;
use App\Models\Category;
use App\Models\ItemCategory;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Response;

class CategoryController extends Controller
{
    /**
     * Display a listing of the resource.
     */
    public function index()
    {
        $category=Category::orderBy('id','DESC')->paginate();
        return Response::json([
            'data'=>CategoryResource::collection($category)->response()->getData(true),
            'success'=>true
        ],200);
    }


     /* Store a newly created resource in storage.
     */
    public function store(CreateCategoryRequest $request)
    {
        $category=new Category;
        $category->name=$request->name;
        $category->description=$request->description;
        $category->save();
        return Response::json([
            'data' => new CategoryResource($category),
            'success'=> true,
            'message'=> " Category Created Successfully"

        ],201);
    }

    /**
     * Display the specified resource.
     */
    public function show(string $id)
    {
        $category = Category::find($id);

        if ($category) {
            return Response::json([
                'data' => new CategoryResource($category),
                'success' => true
            ],200);
        } else {
            return Response::json([
                'data' => $category,
                'success' => false,
                'message' => 'Category not found'
            ], 404);
        }
    }

    /**
     * Show the form for editing the specified resource.
     */
    public function edit(string $id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(UpdateCategoryRequest $request, string $id)
    {
        $category = Category::find($id);
        if($category)
        {
            $category->name=$request->name;
            $category->description=$request->description;
            $category->save();
            return Response::json([
                'data'=> new CategoryResource($category),
                'success'=> 'true',
                'message'=> 'Update Category Successfully',
            ],201);

        }
        // else {
        //     return Response::json([
        //         'data'=> $category,
        //         'success'=> 'false',
        //         'message'=> 'Category not found',
        //     ],404);
        // }
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy(string $id)
    {
        //check if the category is associate with any items
        // $ssociateditems = ItemCategory::where('category_id', $id)->first();
////////////////////////////////////////////
        // category deleted
        $category=Category::find($id);
        if($category){
            return Response::json([
                //'data'=> $category,
                'success'=> 'True',
                'message'=> 'Category Deleted',
            ],200);
        }
        else{
            return Response::json([
                'data'=> $category,
                'success'=> 'False',
                'message'=> 'Category Not found',
            ],404);

        }

        ///////////////////////////////////////


    }
}
